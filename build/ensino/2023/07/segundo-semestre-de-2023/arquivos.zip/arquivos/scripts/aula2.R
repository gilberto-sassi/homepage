# instalação de pacotes
install.packages("readxl")
install.packages("writexl")
install.packages("janitor")
install.packages("tidyverse")

# carregando os pacotes
library(readxl)
library(writexl)
library(janitor)
library(tidyverse)

# ler arquivos do excel
dados_salvador <- read_excel("dados/brutos/salvador.xlsx")

# exercício
help(mean)
log(10, base = 3)



# tipo de dados -----------------------------------------------------------

# string ou caracter
# PRECISA VIR ENTRE ASPAS
# string podem ter letras maiúsculas, 
# caracteres especiais
class("Eu sou Gilberto - coração.")

# número real
# todos os números são reais por padrão
class(10000.33)

# número inteiro
class(1L)

# número complexo
class(1 - 1i)

# valor lógico
class(TRUE)
