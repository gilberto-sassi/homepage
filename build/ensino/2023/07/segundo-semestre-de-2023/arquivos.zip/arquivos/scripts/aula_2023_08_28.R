library(pacman)

p_load(
  readxl,
  writexl,
  janitor,
  ggthemes,
  tidyverse
)


# vetores -----------------------------------------------------------------

# número reais
primeiro_vetor <- c(37, 21, 22)
primeiro_vetor

class(primeiro_vetor)

sequencia <- seq(from = 1, to = 12, by = 2)
sequencia

vetor <- vector("numeric", 4)
vetor

segundo_vetor <- seq_len(5)
segundo_vetor

terceiro_vetor <- seq_along(primeiro_vetor)
terceiro_vetor

# dois pontos
# atalho para seq(from = inicio, to = fim, by = 1)
novo_vetor <- 2:15
novo_vetor

# character
# a informação de texto: sempre entre aspas
nomes <- c("Ieda", "Estefany", "Álvaro", "Pedro")
nomes

vetor_vazio <- vector("character", 6)
vetor_vazio

# exercícios
exe1 <- seq(from = 0.1, to = 0.5, by = 0.1)
exe1

exe2 <- c(TRUE, TRUE, FALSE)
exe2

exe3 <- c("Marx", "Engels", "Lênin")
exe3

exe4 <- 1:3
exe4


# operações com vetores ---------------------------------------------------

# slicing
nomes
pedaco <- nomes[c(1, 3)]
pedaco

uma_pessoa <- nomes[2]
uma_pessoa

sem_ieda_pedro <- nomes[2:3]
sem_ieda_pedro 


nomes <- c("Enrico", "Ieda", "Estefany", "Pedro",
           "Álvaro")

# operações básicas com vetores numéricos

# soma
v1 <- c(2, 7, 5)
v2 <- c(10, 11, 13)
v1 + v2

# subtração
v1 - v2

# multiplicação
v1 * v2

# divisão
v1 / v2
