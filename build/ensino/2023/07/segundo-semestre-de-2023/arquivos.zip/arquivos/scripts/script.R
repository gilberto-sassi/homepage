library(pacman)

p_load(readxl, writexl, janitor, tidyverse)

dados_iris <- read_excel("dados/brutos/iris.xlsx")
tab <- tabyl(dados_iris, especies)
tab

# colocando total
tab <- adorn_totals(tab)
tab

# porcentagem
tab <- adorn_pct_formatting(tab, digits = 3)
tab

# renomear com rename
tab <- rename(tab, "Frequência Absoluta" = "n",
              "Espécies" = "especies",
              "Porcentagem" = "percent")
tab

dados_salvador <- read_excel("dados/brutos/salvador.xlsx")
dados_salvador <- clean_names(dados_salvador)

# raça
tab_raca <- tabyl(dados_salvador, tp_cor_raca)
tab_raca <- adorn_totals(tab_raca)
tab_raca <- adorn_pct_formatting(tab_raca)
tab_raca <- rename(tab_raca, "Raça" = "tp_cor_raca")
write_xlsx(tab_raca, "output/tab_raca.xlsx")

# tipo de escola
tab_escola <- tabyl(dados_salvador, tp_escola)
tab_escola <- adorn_totals(tab_escola)
tab_escola <- adorn_pct_formatting(tab_escola)
tab_escola <- rename(tab_escola, "Escola" = "tp_escola")
write_xlsx(tab_escola, "output/tab_escola.xlsx")


tab_escola <- rename(adorn_pct_formatting(adorn_totals(tabyl(dados_salvador, tp_escola))), "Escola" = "tp_escola")


tab_escola <- tabyl(dados_salvador, tp_escola) |>
  adorn_totals() |>
  adorn_pct_formatting() |> 
  rename("Escola" = "tp_escola")





