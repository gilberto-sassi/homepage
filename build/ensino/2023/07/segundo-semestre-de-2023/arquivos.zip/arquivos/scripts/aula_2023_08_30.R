library(pacman)

p_load(
  readxl,
  writexl,
  janitor,
  ggthemes,
  tidyverse
)

x <- seq_len(5)

# função composta
resultado1 <- log(sqrt(sum(x^2)))
resultado1

resultado2 <- x^2 |> sum() |> sqrt() |> log()
resultado2

# fatores
x <- c("Jan", "Dez", "Fev", "Mar", "Jan", "Dez")

meses <- c(
  "Jan", "Fev", "Mar", "Abril", "Maio", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"
)

x_fator <- fct(x, levels = meses)
x_fator

levels(x_fator)

meses2 <- c(
  "Dez", "Nov", "Out", "Set", "Ago", "Jul", "Jun", "Maio", "Abril", "Mar", "Fev", "Jan"
)

x_fator_ao_contraio <- fct_relevel(x_fator, meses2)
x_fator_ao_contraio
sort(x_fator_ao_contraio)

x_fator_novo <- fct_recode(x_fator,
                           "Dezembro" = "Dez"
                           )
sort(x_fator_novo)

x_fator_sem <- fct_collapse(
  x_fator,
  "1sem" = c("Jun", "Maio", "Abril", "Mar", "Fev", "Jan"),
  "2sem" = c("Dez", "Nov", "Out", "Set", "Ago", "Jul")
)
x_fator_sem


# salvador ----------------------------------------------------------------

dados_salvador <- read_xlsx("dados/brutos/salvador.xlsx")
dados_salvador <- clean_names(dados_salvador)


generos <- c("Feminino", "Masculino")
dados_salvador_limpo <- dados_salvador |> 
  mutate(tp_sexo = fct(tp_sexo, levels = generos)) |> 
  mutate(tp_sexo = fct_recode(tp_sexo, "M" = "Masculino", "F" = "Feminino"))
tab_sexo <- tabyl(dados_salvador_limpo, tp_sexo) |> 
  adorn_totals() |> 
  adorn_pct_formatting() |> 
  rename(
    "Gênero" = "tp_sexo",
    "Frequência" = "n",
    "Porcentagem" = "percent"
  )
write_xlsx(tab_sexo, "output/tab_sexo.xlsx")




rendas <- c(
  "Nenhuma Renda",
  "Até R$ 1.100,00",
  "De R$ 1.100,01 até R$ 1.650,00",
  "De R$ 1.650,01 até R$ 2.200,00",
  "De R$ 2.200,01 até R$ 2.750,00",
  "De R$ 2.750,01 até R$ 3.300,00",
  "De R$ 3.300,01 até R$ 4.400,00",
  "De R$ 4.400,01 até R$ 5.500,00",
  "De R$ 5.500,01 até R$ 6.600,00",
  "De R$ 6.600,01 até R$ 7.700,00",
  "De R$ 7.700,01 até R$ 8.800,00",
  "De R$ 8.800,01 até R$ 9.900,00",
  "De R$ 9.900,01 até R$ 11.000,00",
  "De R$ 11.000,01 até R$ 13.200,00",
  "De R$ 13.200,01 até R$ 16.500,00",
  "De R$ 16.500,01 até R$ 22.000,00",
  "Acima de R$ 22.000,00"
)



dados_salvador_limpo <- dados_salvador_limpo |> 
  mutate(q006 = fct(q006, levels = rendas)) |> 
  mutate(q006 = fct_collapse(
    q006,
    "Renda baixa" = c("Nenhuma Renda",
                      "Até R$ 1.100,00",
                      "De R$ 1.100,01 até R$ 1.650,00",
                      "De R$ 1.650,01 até R$ 2.200,00",
                      "De R$ 2.200,01 até R$ 2.750,00"),
    "Renda média" = c("De R$ 2.750,01 até R$ 3.300,00",
                      "De R$ 3.300,01 até R$ 4.400,00",
                      "De R$ 4.400,01 até R$ 5.500,00",
                      "De R$ 5.500,01 até R$ 6.600,00",
                      "De R$ 6.600,01 até R$ 7.700,00",
                      "De R$ 7.700,01 até R$ 8.800,00",
                      "De R$ 8.800,01 até R$ 9.900,00",
                      "De R$ 9.900,01 até R$ 11.000,00"),
    "Renda alta" = c("De R$ 11.000,01 até R$ 13.200,00",
                     "De R$ 13.200,01 até R$ 16.500,00",
                     "De R$ 16.500,01 até R$ 22.000,00",
                     "Acima de R$ 22.000,00")
  ))
tab_renda <- tabyl(dados_salvador_limpo, q006) |> 
  adorn_totals() |> 
  adorn_pct_formatting() |> 
  rename(
    "Renda" = "q006",
    "Frequência" = "n",
    "Porcentagem" = "percent"
  )
tab_renda
